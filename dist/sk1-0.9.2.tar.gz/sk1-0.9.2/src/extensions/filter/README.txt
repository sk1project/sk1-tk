
Streamfilter module
===================

This module provides a variety of file like objects that encode or
decode data in various formats. The stream filters are modelled after
the filters in the PostScript language.

License:
--------

GNU LIBRARY GENERAL PUBLIC LICENSE Version 2

Copyright (C) 1998, 1999 by Bernhard Herzog.