#ifndef PAXMODULE_H
#define PAXMODULE_H

#include "pixmapobject.h"

typedef struct {
    PaxPixmap_FromPixmap_Func Pixmap_FromPixmap;
} Pax_Functions;



#endif /* PAXMODULE_H */
