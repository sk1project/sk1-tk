
Pax, version 0.6.0
==================


What is Pax?
------------

Pax is a Python module that allows direct access to Xlib functions and
data structures. In addition it defines Tk-widget class that can be 
used to implement widgets in Python.


It is based on the X-extension. The Tk specific part is completely new.


License:
--------

See the files COPYING



