
import fill_plugin, outlineprop, outlinecolor#, gradient_fill