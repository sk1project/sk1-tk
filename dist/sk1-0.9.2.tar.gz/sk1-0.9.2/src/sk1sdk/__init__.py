PKGDIR = __path__[0]
